// script.js

// --- Inicialización del carrito desde localStorage ---
let cart = JSON.parse(localStorage.getItem("cart")) || [];

// --- Actualiza el contador en el header ---
function updateCartCount() {
  document.getElementById("cart-count").textContent = cart.length;
}

// --- Agregar al carrito ---
document.addEventListener("click", function (e) {
  if (e.target.classList.contains("add-to-cart")) {
    const name = e.target.getAttribute("data-name");
    const price = parseInt(e.target.getAttribute("data-price"));

    cart.push({ name, price });
    localStorage.setItem("cart", JSON.stringify(cart));
    updateCartCount();
  }
});

// --- Mostrar productos en checkout.html ---
function renderCart() {
  const cartItemsContainer = document.getElementById("cart-items");
  const cartTotalElement = document.getElementById("cart-total");

  if (!cartItemsContainer) return;

  cartItemsContainer.innerHTML = "";
  let total = 0;

  cart.forEach((item, index) => {
    total += item.price;
    const div = document.createElement("div");
    div.classList.add("list-group-item", "d-flex", "justify-content-between", "align-items-center");
    div.innerHTML = `
      ${item.name} - $${item.price} CLP
      <button class="btn btn-danger btn-sm remove-item" data-index="${index}">X</button>
    `;
    cartItemsContainer.appendChild(div);
  });

  cartTotalElement.textContent = total;
}

// --- Eliminar productos ---
document.addEventListener("click", function (e) {
  if (e.target.classList.contains("remove-item")) {
    const index = e.target.getAttribute("data-index");
    cart.splice(index, 1);
    localStorage.setItem("cart", JSON.stringify(cart));
    renderCart();
    updateCartCount();
  }
});

// --- Botón de finalizar compra ---
document.addEventListener("DOMContentLoaded", function () {
  updateCartCount();
  renderCart();

  const checkoutBtn = document.getElementById("checkout-btn");
  if (checkoutBtn) {
    checkoutBtn.addEventListener("click", () => {
      alert("✅ ¡Gracias por tu compra!");
      cart = [];
      localStorage.removeItem("cart");
      renderCart();
      updateCartCount();
    });
  }
});
