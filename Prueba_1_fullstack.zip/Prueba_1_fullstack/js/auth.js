document.addEventListener("DOMContentLoaded", () => {
  const loginItem = document.getElementById("loginItem");
  const userMenu = document.getElementById("userMenu");
  const usernameDisplay = document.getElementById("usernameDisplay");
  const logoutBtn = document.getElementById("logoutBtn");

  // Verificar si hay usuario guardado
  const savedUser = localStorage.getItem("username");

  if (savedUser) {
    if (loginItem) loginItem.classList.add("d-none"); // Ocultar "Iniciar sesión"
    if (userMenu) userMenu.classList.remove("d-none"); // Mostrar menú usuario
    if (usernameDisplay) usernameDisplay.textContent = `👋 ${savedUser}`;
  } else {
    if (loginItem) loginItem.classList.remove("d-none");
    if (userMenu) userMenu.classList.add("d-none");
  }

  // Botón de cerrar sesión
  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      localStorage.removeItem("username");
      location.href = "index.html"; // Redirigir al inicio
    });
  }
});
